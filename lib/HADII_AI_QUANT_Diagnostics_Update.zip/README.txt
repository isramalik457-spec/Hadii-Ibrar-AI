HADII AI QUANT - Diagnostics Update

Package contents:
- index.html (root)
- lib/strategy.js

Upload/replace these files at the matching paths in your GitHub repository:
- index.html
- lib/strategy.js

This update adds detailed diagnostics counters only:
- Double/Triple Top and Bottom
- BUY/SELL OB and FVG discoveries
- BUY/SELL two-candle H4 liquidity sweeps
- M5 Engulfing, Pin Bar, and Rejection confirmations
- Risk/target rejection counts (SL > $12, RR below 1:2, invalid SL, missing valid TP)

The trading setup conditions and signal-generation rules were not intentionally changed.
Both JavaScript files passed Node.js syntax checks. A basic runtime check confirmed the nested diagnostics fields are returned.
